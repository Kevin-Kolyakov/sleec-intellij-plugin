from operator import *

'''
subsituting  
'''
def fol_subs(source, target, expr):
    pass
