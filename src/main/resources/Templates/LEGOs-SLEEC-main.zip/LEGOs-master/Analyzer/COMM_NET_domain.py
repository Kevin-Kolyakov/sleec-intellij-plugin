from type_constructor import *
from logic_operator import *

COMM_STEPS = 3
type_dict = dict()

create_type("communication_counter",type_dict, lower_bound=0, upper_bound=COMM_STEPS)




